package ParkingSystem;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Parkingsystem {
	 static int totalSlots, availableSlots;
	 static ArrayList<String> parkedVehicle = new ArrayList<String>();
	 public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the total number of parking slots:");
	        try {
	        	totalSlots = sc.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Please Enter a Natural Number");
			}
	        availableSlots = totalSlots;

	        while (true){
	            System.out.println("\nWhat would you like to do?");
	            System.out.println("1. Park a Vehicle");
	            System.out.println("2. Remove a Vehicle");
	            System.out.println("3. View parked Vehicles");
	            System.out.println("4. Exit");
	            int choice=sc.nextInt();
	            switch (choice) {
	                case 1:
	                    parkVehicle();
	                    break;
	                case 2:
	                    removeVehicle();
	                    break;
	                case 3:
	                    viewParkedVehicles();
	                    break;
	                case 4:
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }
	    }

	    public static void parkVehicle() {
	        if (availableSlots == 0) {
	            System.out.println("Sorry, there are no available parking slots.");
	            return;
	        }

	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the license plate number of the Vehicle:");
	        String licensePlate = sc.nextLine();
	        parkedVehicle.add(licensePlate);
	        availableSlots--;
	        System.out.println("Vehicle parked successfully, Vehicle License Number is : " +licensePlate+
	        		"\nThe Avaliable Parking Slots is: "+ availableSlots);
	    }

	    public static void removeVehicle() {
	        if (availableSlots == totalSlots) {
	            System.out.println("There are no parked Vehicles.");
	            return;
	        }

	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the license plate number of the Vehicle to be removed: ");
	        String licensePlate = sc.nextLine();
	        if (parkedVehicle.contains(licensePlate)) {
	        	parkedVehicle.remove(licensePlate);
	            availableSlots++;
	            System.out.println("Vehicle removed successfully. "
	            		+ "\nAvailable slots: " + availableSlots);
	        } else {
	            System.out.println("The Vehicle is not parked here.");
	        }
	    }

	    public static void viewParkedVehicles() {
	        if (availableSlots == totalSlots) {
	            System.out.println("There are no parked Vehicles here."
	            		+ "\nIf you want to park Vehicle please enter the Number 1");
	            return;
	        }

	        System.out.println("The total Number of Parked Vehicles is: "+parkedVehicle.size());
	        for (String licensePlate : parkedVehicle) {
	            System.out.println("License plate of the Vehicle: "+licensePlate);
	        }
	    }
	}
	    

